/*=============== SHOW MENU ===============*/

/*===== MENU SHOW =====*/
/* Validate if constant exists */

/*===== MENU HIDDEN =====*/
/* Validate if constant exists */

/*=============== REMOVE MENU MOBILE ===============*/

/*=============== HOME SWIPER ===============*/

/*=============== DEALS TAB ===============*/

/*=============== SHOW SCROLL UP ===============*/
